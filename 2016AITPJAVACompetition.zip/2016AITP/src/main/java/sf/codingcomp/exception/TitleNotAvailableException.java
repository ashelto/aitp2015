package sf.codingcomp.exception;

public class TitleNotAvailableException extends RuntimeException {

    private static final long serialVersionUID = -5823786826475345070L;

}
